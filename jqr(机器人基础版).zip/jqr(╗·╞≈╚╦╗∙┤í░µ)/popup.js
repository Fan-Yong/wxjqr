var wx_id="0";

function op(e) { 
	
		  chrome.tabs.create({url:"https://wx.qq.com",active:true}, function (tab){});
	  
}





document.addEventListener('DOMContentLoaded', function () {
	
	var bgPage = chrome.extension.getBackgroundPage();	
	var wx_id=bgPage.getWxId();
		
			
	if(wx_id=="0") {				
		var openwx=document.getElementById("owx");
		openwx.style.display="block";
		openwx.addEventListener('click',op);			
	}	else{
		var tip=document.getElementById("tip");				
		tip.style.display="block";		
	}	
			
		
});	