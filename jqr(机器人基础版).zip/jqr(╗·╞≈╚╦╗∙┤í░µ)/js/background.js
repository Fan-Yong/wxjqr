﻿

var wx_id=0;//微信窗口id;
var wx_time=0;
var phpname="getlog.php";
var mulu="chromewx";
var Rleft="***";
var Rright="***";
var space="----------";
var pre_con="---";
var tids=new Array();
var tidslen=0;
var robotName="高枕";

//接收数据
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse)
{
	
	
    if(request.curcon){ 
    	huida=_getReply(request.curcon);     	
    }	 
  	wx_id=sender.tab.id;  
    wx_time=new Date().getTime();  //收到最后一句话的时间 
    	 
       
});


chrome.tabs.onRemoved.addListener(function(tabId,removeInfo){ 
		
		if(tabId==wx_id) wx_id=0;
});

function checkWxExist(){
	if(new Date().getTime()-wx_time>6000){
		wx_id=0;
		return 0;
	}	
	return 1;
}	

function getWxId(){
	return wx_id;	
}	


//微信中每句话的序列号
function getTalkId(i){ 
 	var talkid="000";
 	var regExp =/\((\d){5,}\)$/gi; 
 	if (res = regExp.exec(i)){
			talkid=res[0].replace("(","").replace(")","");
	}
  return talkid;
} 
//说话人姓名
 function getTalkName(i){ 
 	var talkname=" ";
 	var regExp =/^[\s\S]*:/gi; 
 	if (res = regExp.exec(i)){
			talkname=res[0].replace(":","");
	}
  return talkname;
} 

//说话人姓名
 function getTalkCon(i){ 
 	con=i.replace(getTalkName(i)+":","");
 	con=con.replace("("+getTalkId(con)+")","").replace(/^\s*|\s*$/g,"");
 	return con;
} 

function _sendmsg(str){
	chrome.tabs.sendMessage(wx_id,{'msg': Rleft+str+Rright}, kong );
}

function kong(){
}	

//返回""说明没有新增信息，"1"为有新增信息
function  _getReply(temp){	
				
		if(!checkWxExist()) return "";
		temp=temp.replace(/\r\n/g,"<br>")  
    temp=temp.replace(/\n/g,"<br>");     
	  if(pre_con==temp) return "";
		if(temp!="no change" && temp!="no message"){
			pre_con=temp;
			arrs=temp.split(space);
			all_con="";
			for(var i=0;i<arrs.length-1;i++){					
					var arri=arrs[i].replace(/^\s*|\s*$/g,"");	
					arri=arri.toLowerCase();
					
					con=getTalkCon(arri);//聊天内容					
					tid=getTalkId(arri);	//唯一id
					talkname=getTalkName(arri);	//聊天者姓名
									
					if(tidslen>50000){
				  	tids.shift();
				  	tidslen=tidslen-1
				  }					
										
					if(tids.indexOf(tid)>=0)	continue;							
			  	tids.push(tid);						  	
			  	tidslen=tidslen+1;
			  	
			  	/////////调用用户自处理函数//////////////////////////
			  	
			  	
			  	userReply(tid,talkname,con);
			  	
			  	///////////////////////////////////////////////////////
			  	
			  	return "1";
					  	
			}		 
				
		}
		return  "";
	
}

//////////////////////////////////////////////////////////////////////////


function userReply(tid,talkname,con){
	
	if(robotName!=talkname){
		
		_sendmsg(tid+"-"+talkname+"-"+con);
	}	
}	






