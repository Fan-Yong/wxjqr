﻿

var wx_id=0;//微信窗口id;
var wx_time=0;
var phpname="getlog.php";
var mulu="chromewx";
var Rleft="***";
var Rright="***";
var space="----------";
var pre_con="---";
var tids=new Array();
var tidslen=0;
var robotName="高枕";

//接收数据
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse)
{
	
	
    if(request.curcon){ 
    	
    	huida=_getReply(request.curcon);     	
    }	 
  	wx_id=sender.tab.id;  
    wx_time=new Date().getTime();  //收到最后一句话的时间 
    	 
       
});



chrome.tabs.onRemoved.addListener(function(tabId,removeInfo){ 
		
		if(tabId==wx_id) wx_id=0;
});

function checkWxExist(){
	if(new Date().getTime()-wx_time>6000){
		wx_id=0;
		return 0;
	}	
	return 1;
}	

function getWxId(){
	return wx_id;	
}	


//微信中每句话的序列号
function getTalkId(i){ 
 	var talkid="000";
 	var regExp =/\((\d){5,}\)$/gi; 
 	if (res = regExp.exec(i)){
			talkid=res[0].replace("(","").replace(")","");
	}
  return talkid;
} 
//说话人姓名
 function getTalkName(i){ 
 	var talkname=" ";
 	var regExp =/^[\s\S]*:/gi; 
 	if (res = regExp.exec(i)){
			talkname=res[0].replace(":","");
			talkname=talkname.replace("?","");
	}
  return talkname;
} 

//说话人姓名
 function getTalkCon(i){ 
 	con=i.replace(getTalkName(i)+":","");
 	con=con.replace("("+getTalkId(con)+")","").replace(/^\s*|\s*$/g,"");
 	return con;
} 

function _sendmsg(str){
	chrome.tabs.sendMessage(wx_id,{'msg': Rleft+str+Rright}, kong );
}

function kong(){
}	

//返回""说明没有新增信息，"1"为有新增信息
function  _getReply(temp){	
				
		if(!checkWxExist()) return "";
		temp=temp.replace(/\r\n/g,"<br>")  
    temp=temp.replace(/\n/g,"<br>");     
	  if(pre_con==temp) return "";
		if(temp!="no change" && temp!="no message"){
			pre_con=temp;
			arrs=temp.split(space);
			all_con="";
			for(var i=0;i<arrs.length-1;i++){					
					var arri=arrs[i].replace(/^\s*|\s*$/g,"");	
					arri=arri.toLowerCase();
					
					con=getTalkCon(arri);//聊天内容					
					tid=getTalkId(arri);	//唯一id
					talkname=getTalkName(arri);	//聊天者姓名
									
					if(tidslen>50000){
				  	tids.shift();
				  	tidslen=tidslen-1
				  }					
										
					if(tids.indexOf(tid)>=0)	continue;							
			  	tids.push(tid);						  	
			  	tidslen=tidslen+1;
			  	
			  	/////////调用用户自处理函数//////////////////////////
			  	
			  	
			  	userReply(talkname,con);
			  	
			  	///////////////////////////////////////////////////////
			  	
			  	return "1";
					  	
			}		 
				
		}
		return  "";
	
}
//此函数可以用来测试基础功能
//function userReply(tid,talkname,con){
	
//	if(robotName!=talkname){
		
//		_sendmsg(tid+"-"+talkname+"-"+con);
//	}	
//}	


//以上为标准接口程序

//////////////////////////////////////////////////////////////////////////

function userReply(talkname,con){
	
	if (con.indexOf(keyvalue1)==0){
		sendmsg(con,talkname);
	}	
}	

function sendmsg(str1,talkname){
	console.log(talkname+":"+str1);
	
	var l = str1.length;
	var blen = 0;
	for(i=0; i<l; i++) {
	if ((str1.charCodeAt(i) & 0xff00) != 0) {
	blen ++;
	}
	blen ++;
	}
	if(blen<20) return;
	if(blen>20000) str1= "超长("+new Date()+")"; 	
		$.ajax({
		url:"http://www.datun.com.cn/soft/sen/bzr.php", 
		async: false,
		data:{"talks":talkname+":"+str1}, 
		type:"POST", 

		success:function(req){
			if(chrome.runtime.lastError){
				console.log(req);
			}
			
			if(req.indexOf("1")>=0)
				_sendmsg("已经为"+talkname+"记录( http://www.datun.com.cn/soft/sen/getrecord.php  )" );
			//if(req.indexOf("2")>=0)
				//_sendmsg("已经录入过相同信息，若确定再次录入，请改变内容！" );
			if(req.indexOf("0")>=0)
				_sendmsg("对不起，录入失败" );
			return;
		},
		complete:function(){
			//请求完成的处理
			
		},
		error:function(){
		  console.log('error');
		  return;
		}
	})	
}




